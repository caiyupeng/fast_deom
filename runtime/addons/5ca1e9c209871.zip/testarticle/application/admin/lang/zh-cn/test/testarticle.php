<?php

return [
    'Name'  =>  '标题',
    'Image'  =>  '图片',
    'Createtime'  =>  '创建时间',
    'Updatetime'  =>  '更新时间'
];
