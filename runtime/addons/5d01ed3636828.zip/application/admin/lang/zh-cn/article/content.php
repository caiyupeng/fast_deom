<?php

return [
    'Id'                  => '主键ID',
    'Title'               => '标题',
    'Article_category_id' => '类型',
    'Images'              => '图片',
    'Avatar'              => '头图',
    'Author'              => '作者',
    'Resource'            => '来源',
    'Desc'                => '简介',
    'Content'             => '文章详情',
    'Virtualreadnum'      => '初始阅读数',
    'Readnum'             => '阅读数',
    'Status'              => '是否上线',
    'Status 1'            => '上线',
    'Status 2'            => '下线',
    'Createtime'          => '创建时间',
    'Updatetime'          => '更新时间',
    'Deletetime'          => '删除时间',
    'Category.name'       => '分类名称'
];
