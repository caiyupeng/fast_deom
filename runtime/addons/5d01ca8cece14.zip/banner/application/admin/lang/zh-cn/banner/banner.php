<?php

return [
    'Id'         => 'id',
    'Name'       => '轮播图名称',
    'Url'        => '链接',
    'Remark'     => '备注说明',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间',
    'Status'     => '状态',
    'Status 1'   => '启用',
    'Status 2'   => '无效',
    'Weigh'      => '权重',
    'Image'      => '图片'
];
