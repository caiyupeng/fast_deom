<?php

return [
    'Id'             => '公众号ID',
    'Name'           => '公众号名称',
    'Appid'          => 'appId',
    'Appsecret'      => 'appSecret',
    'Token'          => 'token',
    'Accesstoken'    => 'accesstoken',
    'Createtime'     => '创建时间',
    'Updatetime'     => '更新时间',
    'Deletetime'     => '删除时间',
    'Encodingaeskey' => '秘钥',
    'Status'         => '状态',
    'Status 1'       => '启用',
    'Status 2'       => '无效'
];
