<?php

namespace app\common\model\weixin;

use think\Model;

class Member extends Model
{
    // 表名
    protected $name = 'weixin_member';

    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'int';

    // 定义时间戳字段名
    protected $createTime = 'createtime';
    protected $updateTime = 'updatetime';

    // 追加属性
    protected $append = [
        'sex_text',
        'userstatus_text',
        'singlestatus_text',
        'educationstatus_text',
        'marrystatus_text',
        'promisestatus_text',
        'registerstatus_text'
    ];


    protected static function init()
    {
        self::afterInsert(function ($row) {
            $pk = $row->getPk();
            $row->getQuery()->where($pk, $row[$pk])->update([ 'weigh' => $row[$pk] ]);
        });
    }


    public function getSexList()
    {
        return [ '1' => __('男'), '2' => __('女') ];
    }

    public function getUserstatusList()
    {
        return [ '1' => __('群众'), '2' => __('团员'), '3' => __('党员') ];
    }

    public function getSinglestatusList()
    {
        return [ '1' => __('是'), '2' => __('否') ];
    }

    public function getEducationstatusList()
    {
        return [
            '1' => __('博士'),
            '2' => __('硕士'),
            '3' => __('本科'),
            '4' => __('专科'),
            '5' => __('高中'),
            '6' => __('初中'),
            '7' => __('其他')
        ];
    }

    public function getMarrystatusList()
    {
        return [ '1' => __('未婚'), '2' => __('离异'), '3' => __('丧偶') ];
    }

    public function getPromisestatusList()
    {
        return [ '1' => __('是'), '2' => __('否') ];
    }

    public function getRegisterstatusList()
    {
        return [ '1' => __('已注册'), '2' => __('未注册') ];
    }


    public function getSexTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['sex']) ? $data['sex'] : '');
        $list  = $this->getSexList();

        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getUserstatusTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['userstatus']) ? $data['userstatus'] : '');
        $list  = $this->getUserstatusList();

        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getSinglestatusTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['singlestatus']) ? $data['singlestatus'] : '');
        $list  = $this->getSinglestatusList();

        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getEducationstatusTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['educationstatus']) ? $data['educationstatus'] : '');
        $list  = $this->getEducationstatusList();

        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getMarrystatusTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['marrystatus']) ? $data['marrystatus'] : '');
        $list  = $this->getMarrystatusList();

        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getPromisestatusTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['promisestatus']) ? $data['promisestatus'] : '');
        $list  = $this->getPromisestatusList();

        return isset($list[$value]) ? $list[$value] : '';
    }

    public function getRegisterstatusAttr($value, $data)
    {
        return (int)$value;
    }

    public function getRegisterstatusTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['registerstatus']) ? $data['registerstatus'] : '');
        $list  = $this->getRegisterstatusList();

        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getCreatetimeTextAttr($value, $data)
    {
        $value = $value ? $value : $data['createtime'];

        return is_numeric($value) ? date("Y-m-d H:i:s", $value) : $value;
    }

    public function getUpdatetimeTextAttr($value, $data)
    {
        $value = $value ? $value : $data['updatetime'];

        return is_numeric($value) ? date("Y-m-d H:i:s", $value) : $value;
    }

    protected function setCreatetimeAttr($value)
    {
        return $value && !is_numeric($value) ? strtotime($value) : $value;
    }

    protected function setUpdatetimeAttr($value)
    {
        return $value && !is_numeric($value) ? strtotime($value) : $value;
    }


}
