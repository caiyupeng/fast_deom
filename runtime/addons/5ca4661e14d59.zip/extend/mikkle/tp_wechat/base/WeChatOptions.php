<?php
/**
 * Created by PhpStorm.
 * Power By Mikkle
 * Email：776329498@qq.com
 * Date: 2017/7/25
 * Time: 12:04
 */

namespace mikkle\tp_wechat\base;


class WeChatOptions
{
    protected $optionsStorageMode="mysql";

    public function __construct($appId, $options_storage_mode="")
    {





    }




}