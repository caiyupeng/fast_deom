<?php

return [
    'Id'  =>  '小程序ID',
    'Name'  =>  '小程序名称',
    'Appid'  =>  'appId',
    'Appsecret'  =>  'appSecret',
    'Token'  =>  'token',
    'Accesstoken'  =>  'accesstoken',
    'Createtime'  =>  '创建时间',
    'Updatetime'  =>  '更新时间',
    'Deletetime'  =>  '删除时间',
    'Encodingaeskey'  =>  '秘钥',
    'Status'  =>  '状态',
    'Status 0'  =>  '未启用',
    'Status 1'  =>  '启用'
];
