<?php

return [
    'Id'  =>  'ID',
    'Openid'  =>  '用户openid',
    'Nickname'  =>  '昵称',
    'Sex'  =>  '性别',
    'Sex 0'  =>  '未知',
    'Sex 1'  =>  '男',
    'Sex 2'  =>  '女',
    'Province'  =>  '省份',
    'City'  =>  '城市',
    'Country'  =>  '国家',
    'Headimgurl'  =>  '头像',
    'Language'  =>  '语言',
    'Createtime'  =>  '创建时间',
    'Updatetime'  =>  '更新时间'
];
