<?php
/**
 * Created by PhpStorm.
 * Power By Mikkle
 * Email：776329498@qq.com
 * Date: 2017/9/5
 * Time: 16:06
 */

namespace mikkle\tp_wechat\src;


use mikkle\tp_wechat\base\WechatBase;
use mikkle\tp_wechat\support\Curl;
use mikkle\tp_wechat\support\StaticFunction;

class User extends  WechatBase
{


    /** 获取粉丝列表 */
    const USER_GET_URL = '/user/get?';
    /* 获取粉丝信息 */
    const USER_INFO_URL = '/user/info?';
    /* 批量获取粉丝信息 */
    const USER_BATCH_INFO_URL = '/user/info/batchget?';
    /* 更新粉丝标注 */
    const USER_UPDATEREMARK_URL = '/user/info/updateremark?';

    /** 创建标签 */
    const TAGS_CREATE_URL = '/tags/create?';
    /* 获取标签列表 */
    const TAGS_GET_URL = '/tags/get?';
    /* 更新标签 */
    const TAGS_UPDATE_URL = '/tags/update?';
    /* 删除标签 */
    const TAGS_DELETE_URL = '/tags/delete?';
    /* 获取标签下的粉丝列表 */
    const TAGS_GET_USER_URL = '/user/tag/get?';
    /* 批量为粉丝打标签 */
    const TAGS_MEMBER_BATCHTAGGING = '/tags/members/batchtagging?';
    /* 批量为粉丝取消标签 */
    const TAGS_MEMBER_BATCHUNTAGGING = '/tags/members/batchuntagging?';
    /* 获取粉丝的标签列表 */
    const TAGS_LIST = '/tags/getidlist?';

    /** 获取分组列表 */
    const GROUP_GET_URL = '/groups/get?';
    /* 获取粉丝所在的分组 */
    const USER_GROUP_URL = '/groups/getid?';
    /* 创建分组 */
    const GROUP_CREATE_URL = '/groups/create?';
    /* 更新分组 */
    const GROUP_UPDATE_URL = '/groups/update?';
    /* 删除分组 */
    const GROUP_DELETE_URL = '/groups/delete?';
    /* 修改粉丝所在分组 */
    const GROUP_MEMBER_UPDATE_URL = '/groups/members/update?';
    /* 批量修改粉丝所在分组 */
    const GROUP_MEMBER_BATCHUPDATE_URL = '/groups/members/batchupdate?';

    /** 获取黑名单列表 */
    const BACKLIST_GET_URL = '/tags/members/getblacklist?';
    /* 批量拉黑粉丝 */
    const BACKLIST_ADD_URL = '/tags/members/batchblacklist?';
    /* 批量取消拉黑粉丝 */
    const BACKLIST_DEL_URL = '/tags/members/batchunblacklist?';


    public function  __construct(array $option)
    {
        parent::__construct($option);
        $this->getToken();
    }

    /**
     * 批量获取关注粉丝列表
     * @param string $next_openid
     * @return bool|array
     */
    public function getUserList($next_openid = '')
    {
        if ( !$this->access_token ){
            return false;
        }

        $curl_url = self::API_URL_PREFIX . self::USER_GET_URL . "access_token={$this->access_token}&next_openid={$next_openid}";
        $result = Curl::curlGet($curl_url) ;
        return $this->resultJsonWithRetry($result,__FUNCTION__, func_get_args());
    }

    /**
     * 获取关注者详细信息
     * @param string $openid
     * @return bool|array {subscribe,openid,nickname,sex,city,province,country,language,headimgurl,subscribe_time,[unionid]}
     * @注意：unionid字段 只有在粉丝将公众号绑定到微信开放平台账号后，才会出现。建议调用前用isset()检测一下
     */
    public function getUserInfo($openid)
    {
        if (!$this->access_token || empty($openid)){
            return false;
        }
        $curl_url = self::API_URL_PREFIX .  self::USER_INFO_URL . "access_token={$this->access_token}&openid={$openid}";
        $result = Curl::curlGet($curl_url) ;
        return $this->resultJsonWithRetry($result,__FUNCTION__, func_get_args());
    }

    /**
     * 批量获取用户基本信息
     * @param array $openids 用户oepnid列表(最多支持100个openid)
     * @param string $lang 指定返回语言
     * @return bool|mixed
     */
    public function getUserBatchInfo(array $openids, $lang = 'zh_CN')
    {
        if (!$this->access_token || empty($openids)){
            return false;
        }
        $data = ['user_list' => []];
        foreach (array_unique($openids) as $openid) {
            $data['user_list'][] = ['openid' => $openid, 'lang' => $lang];
        }

        $curl_url = self::API_URL_PREFIX . self::USER_BATCH_INFO_URL . "access_token={$this->access_token}";
        $result = Curl::curlPost($curl_url,$data) ;
        if ($result) {
                 $json = StaticFunction::parseJSON($result);
            if (isset($json['errcode']) && !isset($json['user_info_list'])) {
                $this->errCode = $json['errcode'];
                $this->errMsg = $json['errmsg'];
                return $this->checkRetry(__FUNCTION__, func_get_args());
            }
            return $json['user_info_list'];
        }
        return false;
    }

    /**
     * 设置粉丝备注名
     * @param string $openid
     * @param string $remark 备注名
     * @return bool|array
     */
    public function updateUserRemark($openid, $remark)
    {
        if (!$this->access_token || empty($openid)|| empty($remark)){
            return false;
        }

        $data = ['openid' => $openid, 'remark' => $remark];
        $curl_url = self::API_URL_PREFIX .  self::USER_UPDATEREMARK_URL . "access_token={$this->access_token}";
        $result = Curl::curlPost($curl_url,$data) ;

        return $this->resultJsonWithRetry($result,__FUNCTION__, func_get_args());
    }

    /**
     * 获取粉丝分组列表
     * @return bool|array
     */
    public function getGroup()
    {
        if (!$this->access_token ){
            return false;
        }

        $curl_url = self::API_URL_PREFIX . self::GROUP_GET_URL . "access_token={$this->access_token}";
        $result = Curl::curlGet($curl_url) ;
        return $this->resultJsonWithRetry($result,__FUNCTION__, func_get_args());
    }

    /**
     * 删除粉丝分组
     * @param type $id
     * @return bool
     */
    public function delGroup($id)
    {
        if (!$this->access_token || empty($id)){
            return false;
        }

        $data = ['group' => ['id' => $id]];
        $curl_url = self::API_URL_PREFIX .self::GROUP_DELETE_URL . "access_token={$this->access_token}";
        $result = Curl::curlPost($curl_url,$data) ;
        return $this->resultJsonWithRetry($result,__FUNCTION__, func_get_args());
    }

    /**
     * 获取粉丝所在分组
     * @param string $openid
     * @return bool|int 成功则返回粉丝分组id
     */
    public function getUserGroup($openid)
    {
        if (!$this->access_token || empty($openid)){
            return false;
        }


        $data = ['openid' => $openid];
        $curl_url = self::API_URL_PREFIX . self::USER_GROUP_URL . "access_token={$this->access_token}";
        $result = Curl::curlPost($curl_url,$data) ;
        return $this->resultJsonWithRetry($result,__FUNCTION__, func_get_args());
    }

    /**
     * 新增自定分组
     * @param string $name 分组名称
     * @return bool|array
     */
    public function createGroup($name)
    {
        if (!$this->access_token || empty($name)){
            return false;
        }

        $data = ['group' => ['name' => $name]];
        $curl_url = self::API_URL_PREFIX . self::GROUP_CREATE_URL . "access_token={$this->access_token}";
        $result = Curl::curlPost($curl_url,$data) ;
        return $this->resultJsonWithRetry($result,__FUNCTION__, func_get_args());
    }

    /**
     * 更改分组名称
     * @param int $groupid 分组id
     * @param string $name 分组名称
     * @return bool|array
     */
    public function updateGroup($groupid, $name)
    {
        if (!$this->access_token || empty($groupid)|| empty($name)){
            return false;
        }

        $data = ['group' => ['id' => $groupid, 'name' => $name]];
        $curl_url = self::API_URL_PREFIX . self::GROUP_UPDATE_URL . "access_token={$this->access_token}";
        $result = Curl::curlPost($curl_url,$data) ;
        return $this->resultJsonWithRetry($result,__FUNCTION__, func_get_args());
    }

    /**
     * 移动粉丝分组
     * @param int $groupid 分组id
     * @param string $openid 粉丝openid
     * @return bool|array
     */
    public function updateGroupMembers($groupid, $openid)
    {
        if (!$this->access_token || empty($openid) || empty($groupid)) {
            return false;
        }

        $data = ['openid' => $openid, 'to_groupid' => $groupid];
        $curl_url = self::API_URL_PREFIX . self::GROUP_MEMBER_UPDATE_URL . "access_token={$this->access_token}";
        $result = Curl::curlPost($curl_url, $data);
        return $this->resultJsonWithRetry($result, __FUNCTION__, func_get_args());
    }

    /**
     * 批量移动粉丝分组
     * @param string $groupid 分组ID
     * @param string $openid_list 粉丝openid数组(一次不能超过50个)
     * @return bool|array
     */
    public function batchUpdateGroupMembers($groupid, $openid_list)
    {
        if (!$this->access_token || empty($groupid) || empty($openid_list) ){
            return false;
        }

        $data = ['openid_list' => $openid_list, 'to_groupid' => $groupid];
        $curl_url = self::API_URL_PREFIX . self::GROUP_MEMBER_BATCHUPDATE_URL . "access_token={$this->access_token}";
        $result = Curl::curlPost($curl_url,$data) ;
        return $this->resultJsonWithRetry($result,__FUNCTION__, func_get_args());
    }

    /**
     * 新增自定标签
     * @param string $name 标签名称
     * @return bool|array
     */
    public function createTags($name)
    {
        if (!$this->access_token || empty($name)){
            return false;
        }

        $data = ['tag' => ['name' => $name]];
        $curl_url = self::API_URL_PREFIX . self::TAGS_CREATE_URL . "access_token={$this->access_token}";
        $result = Curl::curlPost($curl_url,$data) ;
        return $this->resultJsonWithRetry($result,__FUNCTION__, func_get_args());
    }

    /**
     *  更新标签
     * @param string $id 标签id
     * @param string $name 标签名称
     * @return bool|array
     */
    public function updateTag($id, $name)
    {
        if (!$this->access_token || empty($id) || empty($name)){
            return false;
        }

        $data = ['tag' => ['id' => $id, 'name' => $name]];
        $curl_url = self::API_URL_PREFIX . self::TAGS_UPDATE_URL . "access_token={$this->access_token}";
        $result = Curl::curlPost($curl_url,$data) ;
        return $this->resultJsonWithRetry($result,__FUNCTION__, func_get_args());
    }

    /**
     * 获取粉丝标签列表
     * @return bool|array
     */
    public function getTags()
    {
        if (!$this->access_token ){
            return false;
        }

        $curl_url = self::API_URL_PREFIX .  self::TAGS_GET_URL . "access_token={$this->access_token}";
        $result = Curl::curlGet($curl_url) ;
        return $this->resultJsonWithRetry($result,__FUNCTION__, func_get_args());
    }

    /**
     * 删除粉丝标签
     * @param string $id
     * @return bool
     */
    public function delTag($id)
    {
        if (!$this->access_token || empty($id)){
            return false;
        }

        $data = ['tag' => ['id' => $id]];
        $curl_url = self::API_URL_PREFIX . self::TAGS_DELETE_URL . "access_token={$this->access_token}";
        $result = Curl::curlPost($curl_url,$data) ;
        return $this->resultJsonWithRetry($result,__FUNCTION__, func_get_args());
    }

    /**
     * 获取标签下的粉丝列表
     * @param string $tagid
     * @param string $next_openid
     * @return bool
     */
    public function getTagUsers($tagid, $next_openid = '')
    {
        if (!$this->access_token || empty($tagid)){
            return false;
        }

        $data = ['tagid' => $tagid, 'next_openid' => $next_openid];
        $curl_url = self::API_URL_PREFIX . self::TAGS_GET_USER_URL . "access_token={$this->access_token}";
        $result = Curl::curlPost($curl_url,$data) ;
        return $this->resultJsonWithRetry($result,__FUNCTION__, func_get_args());
    }

    /**
     *  批量为粉丝打标签
     * @param string $tagid 标签ID
     * @param array $openid_list 粉丝openid数组，一次不能超过50个
     * @return bool|array
     */
    public function batchAddUserTag($tagid, $openid_list)
    {
        if (!$this->access_token || empty($tagid) ||empty($openid_list)){
            return false;
        }

        $data = ['openid_list' => $openid_list, 'tagid' => $tagid];
        $curl_url = self::API_URL_PREFIX . self::TAGS_MEMBER_BATCHTAGGING . "?access_token={$this->access_token}";
        $result = Curl::curlPost($curl_url,$data) ;
        return $this->resultJsonWithRetry($result,__FUNCTION__, func_get_args());
    }

    /**
     *  批量为粉丝取消标签
     * @param string $tagid 标签ID
     * @param array $openid_list 粉丝openid数组，一次不能超过50个
     * @return bool|array
     */
    public function batchDeleteUserTag($tagid, $openid_list)
    {
        if (!$this->access_token ||empty($openid_list) || empty($tagid)  ){
            return false;
        }

        $data = ['openid_list' => $openid_list, 'tagid' => $tagid];
        $curl_url = self::API_URL_PREFIX . self::TAGS_MEMBER_BATCHUNTAGGING . "access_token={$this->access_token}";
        $result = Curl::curlPost($curl_url,$data) ;
        return $this->resultJsonWithRetry($result,__FUNCTION__, func_get_args());
    }

    /**
     *  获取粉丝的标签列表
     * @param string $openid 粉丝openid
     * @return bool|array
     */
    public function getUserTags($openid)
    {
        if (!$this->access_token || empty($openid)){
            return false;
        }

        $data = ['openid' => $openid];
        $curl_url = self::API_URL_PREFIX . self::TAGS_LIST . "access_token={$this->access_token}";
        $result = Curl::curlPost($curl_url,$data) ;
        if ($result) {
                 $json = StaticFunction::parseJSON($result);
            if (!$json || !isset($json['tagid_list']) || !empty($json['errcode'])) {
                $this->errCode = $json['errcode'];
                $this->errMsg = $json['errmsg'];
                return $this->checkRetry(__FUNCTION__, func_get_args());
            }
            return $json['tagid_list'];
        }
        return false;
    }

    /**
     * 批量获取黑名单粉丝
     * @param string $begin_openid
     * @return bool|array
     */
    public function getBacklist($begin_openid = '')
    {
        if (!$this->access_token || empty($begin_openid)){
            return false;
        }

        $data = empty($begin_openid) ? [] : ['begin_openid' => $begin_openid];
        $curl_url = self::API_URL_PREFIX . self::BACKLIST_GET_URL . "access_token={$this->access_token}";
        $result = Curl::curlPost($curl_url,$data) ;
        return $this->resultJsonWithRetry($result,__FUNCTION__, func_get_args());
    }

    /**
     * 批量拉黑粉丝
     * @param string $openids
     * @return bool|array
     */
    public function addBacklist($openids)
    {
        if (!$this->access_token || empty($openids)){
            return false;
        }

        $data = ['openid_list' => $openids];
        $curl_url = self::API_URL_PREFIX . self::BACKLIST_ADD_URL . "access_token={$this->access_token}";
        $result = Curl::curlPost($curl_url,$data) ;
        return $this->resultJsonWithRetry($result,__FUNCTION__, func_get_args());
    }

    /**
     * 批量取消拉黑粉丝
     * @param string $openids
     * @return bool|array
     */
    public function delBacklist($openids)
    {
        if (!$this->access_token || empty($openids)){
            return false;
        }
        $data = ['openid_list' => $openids];
        $curl_url = self::API_URL_PREFIX . self::BACKLIST_DEL_URL . "access_token={$this->access_token}";
        $result = Curl::curlPost($curl_url,$data) ;
        return $this->resultJsonWithRetry($result,__FUNCTION__, func_get_args());
    }


}