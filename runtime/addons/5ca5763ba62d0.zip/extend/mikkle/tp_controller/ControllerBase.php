<?php
/**
 * Created by PhpStorm.
 * User: Mikkle
 * QQ:776329498
 * Date: 2017/12/13
 * Time: 15:14
 */

namespace mikkle\tp_controller;

use think\Controller;

class ControllerBase extends Controller
{

}