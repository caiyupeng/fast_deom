<?php

return [
    'Id'         => 'ID',
    'Pid'        => '父级id',
    'Name'       => '分类名称',
    'Weigh'      => '权重',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间',
    'Deletetime' => '删除时间'
];
